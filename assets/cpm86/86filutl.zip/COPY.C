
ver(n) int n;{
	puts("����������������������������������������������Ŀ");
if(!n){	puts("�Program: COPY86.CMD v1.0    CP/M-86 (IBM-PC)  �");
	puts("�Author : Ken Mauro                            �");
	puts("�Date...: Sept 1, 1998                         �");
	puts("�Purpose: DOS style copy                       �");
	puts("�                                              �");
	puts("�(C)1998 Ken Mauro, all rights reserved.       �");
	puts("�        free for non-commercial use.          �");
	puts("�                                              �");
}if(n){	puts("�Usage..: copy UD:src UD:dest                  �");
	puts("�         copy srcfile 1m:                     �");
	puts("�         copy *.* m:                          �");
	puts("�                                              �");
	puts("�Note...: Press CTRL-C to abort.               �");
	puts("�                                              �");
	puts("�Warning:*DO NOT* interrupt by using the       �");
	puts("�         ctrl-break/scrl-lock key combo.      �");
	puts("�         Like PIP.CMD, the destination        �");
	puts("�         disk directory may be damaged.       �");
}	puts("������������������������������������������������");
}

#include <stdio.h>

#define ON	0
#define OFF	1

long int patchstr = 0x6778797a;		/* DRI's "zyxg" patch area finder */
int echo = 1;				/* 0 = no echo messages */
int diag = 0;				/* 0 = no diag messages */

char arg[64];						/* holds cmdline */
FILE *fp;

main(argc,argv)
	int argc;
	char *argv[];
{
	int c,i,j,n,t,f1,f2;
	int pos,first,next,last;
	int d1,d2,u1,u2;
	int len,len1,len2,ret,tbytes;
	static char space[]={"                   "};	/* must be 19 spaces */	
	char buf[BUFSIZ+1];				/* defined in stdio.h */
	char tmp[16],src[16],dest[16];
	char du[16],du1[16],du2[16];
	

    if(argc >1 ){
    if(argc >2 ){

	puts(" ");

	next = 1;
	last  = argc-1;

	u1 = __BDOS(32,255); 
	d1 = __BDOS(0x19); 
	d1+=97;
	sprintf(tmp,"%u%c:",u1,d1);
	strcpy(du,tmp);


	strcpy(du1,argv[1]);	
	len1 = instr(du1,':');
	if(len1 > 0) du1[len1+1]=0;
	else strcpy(du1,tmp);
	len1=strlen(du1);


	strcpy(du2,argv[last]);	
	len2= instr(du2,':');
	if(len2 > 0) du2[len2+1]=0;
	else strcpy(du2,tmp);
	len2=strlen(du2);


	if(len1==2) {
		sprintf(tmp,"%u%s",u1,du1);
		strcpy(du1,tmp);
		len1=strlen(du1);
		}

	if(len2==2) {
		sprintf(tmp,"%u%s",u1,du2);
		strcpy(du2,tmp);
		len2=strlen(du2);
		}

	if( strcmp(argv[1],argv[2]) != 0 ){
		if( (ret=strcmp(du1,du2)) !=0 ){ 

		len = len1;
	
		ret=instr(argv[1],':'); 
		if(ret > 0) len1=ret+1;
		else len1=0;

		ret=instr(argv[2],':'); 
		if(ret > 0) len2=ret+1;
		else len2=0;

/*===========================================================================*/

while(next++ < last ){

	strcpy(src,du1);	
	strcpy(tmp,argv[next-1]);
	strcat(src,&tmp[len1]);
	if(argc>3){
		strcpy(dest,du2);	
		strcpy(tmp,argv[next-1]);
		strcat(dest,&tmp[len2]);	
		}

	else{	
		if( strcmp(&du2[1],argv[2])==0){ 
			strcpy(dest,du2);	
			strcpy(tmp,argv[next-1]);
			strcat(dest,&tmp[len1]);	
			}
 		else {
			strcpy(dest,du2);	
			strcpy(tmp ,argv[2]);
			strcat(dest,&tmp[len2]);
			}
		}

		len=strlen(src);

		printf("%s%s%s \n",src, &space[len], dest);

		/*printf("%s                 \n",dest);*/

		if((f1=openb (src ,0))== -1) error("Source not found.");
		if((f2=creatb(dest,1))== -1) error("Destination invalid.");

		tbytes=0;
		while( (n=read(f1,buf,BUFSIZ)) > 0){
			if(write(f2,buf,n)!=n) error("Write error/ Disk full.");
			tbytes += n;
			printf("%u bytes copied..   \r",tbytes);
			}
		close(f2);
		close(f1);
		if( __BDOS(6,254) ) ctrlbrk();

		} /* end of copy loop */
		printf("%u file(s) copied.    \r",next-2);

		} else puts("Source: destination is identical or missing.");
	    } else puts("File cannot be copied onto itself.");
	} else puts("You must supply a source and destination.");
   } else{ ver(0); 
	   ver(1); 
	 }

 }

/* =============================== END MAIN ================================ */

instr(a,b)
char *a, *b;
{
	int i=0;
	while( a[i++] != 0 ) { 
		if( a[i] == b ) return(i);
		}
	return(0);
}

error(s)
char *s;
{
	puts(s);
        exit(1);

}

ctrlbrk(c)
int c;
{
	c=__BDOS(6,255);
	if (c=3){
	        puts("*interrupted*          ");
	        exit(1);
	}
}

/* **************************  spare code ********************************* */

 /*
	if(diag){
		printf("*du =%s \n",du);
		printf("du1 =%s \n",du1);
		printf("du2 =%s \n",du2);
		printf("argv[1]   : %s \n",argv[1]);
		printf("argv[2]   : %s \n",argv[2]);
		printf("argv[last]: %s \n",argv[last]);
		printf("#args     : %u \n", last);
		}

	f1=openb(src,0);
	n=read(f1,buf,BUFSIZ);
	d1 = bdos(0x19);
	u1 = bdos(32,255);

	f2=openb(dest,0); 
	n=read(f2,buf,BUFSIZ);
	d2 = bdos(0x19); 
	u2 = bdos(32,255); 

	close(f2);
	close(f1);

	printf("src  %u:%u \n",u1,d1);
	printf("dest %u:%u \n",u2,d2);

if((d1==d2)&&(u1==u2)) error("You must specify different user areas.");  


	if( strcmp(src[3],dest[3]) == 0 ){
		if( strcmp(src,dest) != 0 )
			error("You must specify different user areas.");  
			}



	strcpy(src,argv[next-1]);
	if(argc>3){
		strcpy(dest,du);	
		strcat(dest,&src[len+1]);	
		}
	else {
		if( strcmp(du2,argv[2])==0){ 
				strcpy(dest,du2);	
				strcat(dest,&src[len]);	
				}
		else strcpy(dest,argv[2]);	
		}

*/
